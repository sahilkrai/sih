import HeroSection from "../components/HeroSection";
import StatsSection from "../components/StatsSection";
import QuerySection from "../components/QuerySection";
import AboutSection from "../components/AboutSection";

function Home() {
  return (
    <div>
      <HeroSection />
      <QuerySection />
      <AboutSection />
      <StatsSection />
    </div>
  );
}

export default Home;
