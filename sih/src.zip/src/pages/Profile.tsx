import { useState } from "react";
import { FaUser, FaPhone, FaLanguage, FaEdit, FaSave, FaMapMarkerAlt, FaSeedling } from "react-icons/fa";
import "../styles/Profile.css";

function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [userData, setUserData] = useState({
    name: "Farmer Ramesh",
    phone: "+91 9876543210",
    language: "English",
    location: "Maharashtra, India"
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsEditing(false);
    // Here you would typically save the data to a backend
    console.log("Saving profile data:", userData);
  };

  return (
    <div className="profile-container">
      <div className="profile-header">
        <h2>My Profile</h2>
        <button 
          className="edit-toggle" 
          onClick={() => setIsEditing(!isEditing)}
          aria-label={isEditing ? "Save profile" : "Edit profile"}
        >
          {isEditing ? <FaSave /> : <FaEdit />}
        </button>
      </div>

      <div className="profile-avatar">
        <div className="avatar-circle">
          <FaUser />
        </div>
        {isEditing && <p className="edit-avatar-hint">Click to change photo</p>}
      </div>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>
            Name
            <div className="input-with-icon">
              <input 
                type="text" 
                name="name"
                value={userData.name} 
                onChange={handleChange}
                disabled={!isEditing} 
                placeholder="Enter your name"
              />
            </div>
          </label>
        </div>

        <div className="form-group">
          <label>
            Phone
            <div className="input-with-icon">
              <input 
                type="text" 
                name="phone"
                value={userData.phone} 
                onChange={handleChange}
                disabled={!isEditing} 
                placeholder="Enter your phone number"
              />
            </div>
          </label>
        </div>

        <div className="form-group">
          <label>
            Preferred Language
            <div className="input-with-icon">
              <select 
                name="language"
                value={userData.language} 
                onChange={handleChange}
                disabled={!isEditing}
              >
                <option>English</option>
                <option>हिन्दी</option>
                <option>मराठी</option>
                <option>ਪੰਜਾਬੀ</option>
                <option>ગુજરાતી</option>
              </select>
            </div>
          </label>
        </div>

        <div className="form-group">
          <label>
            Location
            <div className="input-with-icon">
              <input 
                type="text" 
                name="location"
                value={userData.location} 
                onChange={handleChange}
                disabled={!isEditing} 
                placeholder="Enter your location"
              />
            </div>
          </label>
        </div>

        <div className="form-group">
          <label>
            Crops Grown
            <div className="input-with-icon">
              <input 
                type="text" 
                name="crops"
                defaultValue="Wheat, Rice, Cotton" 
                onChange={handleChange}
                disabled={!isEditing} 
                placeholder="Enter crops you grow"
              />
            </div>
          </label>
        </div>

        {isEditing ? (
          <button type="submit" className="save-button">
            <FaSave /> Save Changes
          </button>
        ) : (
          <button type="button" onClick={() => setIsEditing(true)} className="edit-button">
            <FaEdit /> Edit Profile
          </button>
        )}
      </form>
    </div>
  );
}

export default Profile;
