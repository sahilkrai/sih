import { useState } from 'react';
import { FaMicrophone, FaStop } from 'react-icons/fa';
import '../styles/MicrophoneButton.css';

interface MicrophoneButtonProps {
  onAudioCaptured?: (audioBlob: Blob) => void;
}

const MicrophoneButton: React.FC<MicrophoneButtonProps> = ({ onAudioCaptured }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const audioChunks: BlobPart[] = [];

      recorder.addEventListener('dataavailable', (event) => {
        audioChunks.push(event.data);
      });

      recorder.addEventListener('stop', () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        if (onAudioCaptured) {
          onAudioCaptured(audioBlob);
        }
        
        // Stop all tracks to release the microphone
        stream.getTracks().forEach(track => track.stop());
      });

      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Could not access microphone. Please check your permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
    }
  };

  return (
    <button
      className="microphone-button"
      className={`microphone-button ${isRecording ? 'recording' : ''}`}
      onClick={isRecording ? stopRecording : startRecording}
      aria-label={isRecording ? 'Stop recording' : 'Start recording'}
    >
      {isRecording ? <FaStop /> : <FaMicrophone />}
    </button>
  );
};

export default MicrophoneButton;