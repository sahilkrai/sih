import React from 'react';
import '../styles/AboutSection.css';
import { FaLeaf, FaUsers, FaGlobeAsia, FaChartLine } from 'react-icons/fa';

const AboutSection = () => {
  return (
    <section id="about" className="about-section">
      <div className="about-content">
        <h2>About AgriAid</h2>
        <p className="about-intro">
          AgriAid is a revolutionary platform designed to assist farmers with cutting-edge AI technology.
        </p>
        
        <div className="stats-container">
        
          <div className="stat-box">
            <FaLeaf className="stat-icon" />
            <h3>95%</h3>
            <p>Accuracy in Disease Detection</p>
          </div>
          <div className="stat-box">
            <FaGlobeAsia className="stat-icon" />
            <h3>12</h3>
            <p>States Covered</p>
          </div>
          <div className="stat-box">
            <FaChartLine className="stat-icon" />
            <h3>30%</h3>
            <p>Average Yield Increase</p>
          </div>
        </div>
        
        <div className="about-details">
          <div className="about-text">
            <h3>Our Mission</h3>
            <p>
              We provide farmers with the tools and information they need to make informed decisions, increase productivity, and ensure sustainable farming practices.
            </p>
          </div>
          <div className="about-text">
            <h3>What We Offer</h3>
            <p>
              From real-time crop disease detection to personalized advisory services, AgriAid is your trusted partner in modern agriculture. We leverage the power of artificial intelligence to bring you accurate, timely, and actionable insights.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;