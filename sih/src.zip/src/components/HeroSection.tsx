import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../styles/HeroSection.css";
import { scrollToElement } from "../utils/scrollUtils.ts";

const HeroSection = () => {
  const [location, setLocation] = useState('');

  const handleLocationSubmit = (e) => {
    e.preventDefault();
    console.log('Location submitted:', location);
    // Here you would handle the location data
  };

  return (
    <section className="hero">
      <div className="hero-center">
        <h1>
          Welcome to <span>MySite</span>
        </h1>
        <p>
          Explore the future of sleek and modern interfaces with interactive 3D models seamlessly integrated.
        </p>
        <div className="hero-buttons">
          <Link to="/signup" className="btn solid">
            Get Started
          </Link>
          <button onClick={() => scrollToElement('about', 80)} className="btn outline">
            Learn More
          </button>
        </div>
        
        <div className="hero-location-input">
          <form onSubmit={handleLocationSubmit}>
            <div className="location-input-group">
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Enter your location"
                required
              />
              <button type="submit" className="location-submit-btn">
                Set
              </button>
            </div>
          </form>
        </div>
      </div>

    </section>
  );
};

export default HeroSection;


